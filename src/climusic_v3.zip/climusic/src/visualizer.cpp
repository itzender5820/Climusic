/*  CLI.MUSIC.COM — visualizer.cpp  v3.0
 *  BARS  (style 0): braille sub-cell bar chart with optional peak dots.
 *  SCOPE (style 1): 8-dot braille oscilloscope waveform.
 */
#include "visualizer.h"
#include "kissfft/kiss_fft.h"
#include <cmath>
#include <cstring>
#include <algorithm>
#include <numeric>

// ─── init ─────────────────────────────────────────────────────────────────────
void Visualizer::init(int w, int h) {
    std::lock_guard<std::mutex> lk(mtx_);
    width_ = std::max(4, w);
    height_ = std::max(2, h);
    peak_cols_.assign(width_, 0.0f);
    peak_hold_timer_.assign(width_, 0);
}

// ─── push_samples ────────────────────────────────────────────────────────────
void Visualizer::push_samples(std::span<const float> s, int channels, int sr) {
    push_samples(s.data(), (int)s.size() / channels, channels, sr);
}

void Visualizer::push_samples(const float* s, int frames, int channels, int sr) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (sr > 0) sample_rate_ = sr;
    for (int i = 0; i < frames; ++i) {
        float mono = 0.0f;
        for (int c = 0; c < channels; ++c) mono += s[i * channels + c];
        mono /= (float)channels;
        ring_[ring_write_ & (FFT_SIZE_VIZ - 1)] = mono;
        ++ring_write_;
        pcm_ring_[pcm_write_ & (FFT_SIZE_VIZ * 2 - 1)] = mono;
        ++pcm_write_;
    }
}

// ─── FFT band computation ────────────────────────────────────────────────────
void Visualizer::compute_bands_locked(int bands) {
    bands = std::clamp(bands, 1, MAX_BANDS);
    const int N = FFT_SIZE_VIZ;

    kiss_fft_cfg cfg = kiss_fft_alloc(N, 0, nullptr, nullptr);
    if (!cfg) return;

    // Build windowed input (Hann window)
    std::vector<kiss_fft_cpx> in(N), out(N);
    for (int i = 0; i < N; ++i) {
        float w = 0.5f * (1.0f - std::cos(2.0f * (float)M_PI * i / (N - 1)));
        int ri = (ring_write_ - N + i + N * 4) & (N - 1);
        in[i].r = ring_[ri] * w;
        in[i].i = 0.0f;
    }
    kiss_fft(cfg, in.data(), out.data());
    kiss_fft_free(cfg);

    // Compute per-band energy using log-spaced bins
    float half = N / 2.0f;
    float f_low  = 40.0f;
    float f_high = (float)(sample_rate_ / 2);
    float log_lo = std::log2(f_low);
    float log_hi = std::log2(f_high);

    // Smoothing speed based on density (1=fast/fluid, 10=slow/rigid)
    float up_speed   = 0.6f - 0.05f * (float)(density_ - 1);
    float down_speed = 0.08f + 0.018f * (float)(density_ - 1);

    for (int b = 0; b < bands; ++b) {
        float f_start = std::pow(2.0f, log_lo + (log_hi - log_lo) * (float)b     / (float)bands);
        float f_end   = std::pow(2.0f, log_lo + (log_hi - log_lo) * (float)(b+1) / (float)bands);

        int bin_lo = std::max(1, (int)(f_start / (float)sample_rate_ * N));
        int bin_hi = std::max(bin_lo + 1, (int)(f_end / (float)sample_rate_ * N));
        bin_hi = std::min(bin_hi, (int)half);

        float energy = 0.0f;
        for (int k = bin_lo; k < bin_hi; ++k) {
            float re = out[k].r, im = out[k].i;
            energy += re * re + im * im;
        }
        energy = std::sqrt(energy / (float)(bin_hi - bin_lo + 1)) * 0.012f;
        energy = std::clamp(energy, 0.0f, 1.0f);

        float prev = smooth_[b];
        float spd = (energy > prev) ? up_speed : down_speed;
        smooth_[b] = prev + (energy - prev) * spd;
    }
}

// ─── interpolate_cols ────────────────────────────────────────────────────────
std::vector<float> Visualizer::interpolate_cols(
    const std::array<float, MAX_BANDS>& snap, int bands, float scale) const
{
    std::vector<float> cols(width_, 0.0f);
    for (int c = 0; c < width_; ++c) {
        float fi = (float)c / (float)(width_ - 1) * (float)(bands - 1);
        int  i0  = (int)fi;
        int  i1  = std::min(i0 + 1, bands - 1);
        float t  = fi - i0;
        cols[c]  = std::clamp((snap[i0] * (1.0f - t) + snap[i1] * t) * scale, 0.0f, 1.0f);
    }
    return cols;
}

// ─── render ──────────────────────────────────────────────────────────────────
VisualizerFrame Visualizer::render(VizStyle style, int bands) {
    std::lock_guard<std::mutex> lk(mtx_);
    compute_bands_locked(bands);
    std::array<float, MAX_BANDS> snap = smooth_;

    if (style == VizStyle::SCOPE) return render_scope();
    return render_bars(snap, bands);
}

// ─── BARS ─────────────────────────────────────────────────────────────────────
VisualizerFrame Visualizer::render_bars(
    const std::array<float, MAX_BANDS>& snap, int bands)
{
    auto cols = interpolate_cols(snap, bands);

    // Ensure peak_cols_ is correctly sized
    if ((int)peak_cols_.size() != width_) {
        peak_cols_.assign(width_, 0.0f);
        peak_hold_timer_.assign(width_, 0);
    }

    VisualizerFrame frame;
    frame.width  = width_;
    frame.height = height_;
    frame.style  = VizStyle::BARS;
    frame.rows.assign(height_, std::vector<uint32_t>(width_, (uint32_t)' '));

    const int sub_cells = height_ * 4;

    for (int c = 0; c < width_; ++c) {
        float val = cols[c];

        // Peak hold
        if (peak_hold_) {
            if (val >= peak_cols_[c]) {
                peak_cols_[c] = val;
                peak_hold_timer_[c] = 20;
            } else {
                if (peak_hold_timer_[c] > 0) --peak_hold_timer_[c];
                else peak_cols_[c] = std::max(0.0f, peak_cols_[c] - 0.015f);
            }
        }

        int filled = (int)(val * sub_cells);
        filled = std::clamp(filled, 0, sub_cells);

        // Fill rows bottom-up
        for (int r = height_ - 1; r >= 0; --r) {
            int avail = std::min(filled, 4);
            filled -= avail;
            if (avail > 0)
                frame.rows[r][c] = (uint32_t)BRAILLE_LEVEL[avail];
            // else already ' '
        }

        // Peak dot
        if (peak_hold_ && peak_cols_[c] > 0.01f) {
            int peak_sc = (int)(peak_cols_[c] * sub_cells);
            int peak_r  = height_ - 1 - (peak_sc / 4);
            if (peak_r >= 0 && peak_r < height_)
                frame.rows[peak_r][c] = 0x2022u; // bullet = peak marker
        }
    }
    return frame;
}

// ─── SCOPE ────────────────────────────────────────────────────────────────────
VisualizerFrame Visualizer::render_scope() {
    VisualizerFrame frame;
    frame.width  = width_;
    frame.height = height_;
    frame.style  = VizStyle::SCOPE;
    frame.rows.assign(height_, std::vector<uint32_t>(width_, 0x2800u)); // empty braille

    const int pcm_n = FFT_SIZE_VIZ * 2;
    // Sample one waveform point per terminal column
    for (int c = 0; c < width_; ++c) {
        // Map column to a PCM sample index
        int offset = (pcm_write_ - width_ + c + pcm_n * 4) & (pcm_n - 1);
        float v = pcm_ring_[offset];
        v = std::clamp(v, -1.0f, 1.0f);

        // Map -1…1 to a braille row + sub-row
        // height_ rows × 4 sub-rows = total sub-rows
        float norm = (v + 1.0f) * 0.5f;              // 0…1
        int sub_y  = (int)(norm * (float)(height_ * 4 - 1));
        sub_y = std::clamp(sub_y, 0, height_ * 4 - 1);

        int row    = height_ - 1 - (sub_y / 4);
        int sub    = sub_y % 4;
        // Use left-dot braille column for each terminal column
        if (row >= 0 && row < height_) {
            uint32_t dot = (uint32_t)BRAILLE_DOT[sub][0];
            frame.rows[row][c] = dot;
        }
    }
    return frame;
}
