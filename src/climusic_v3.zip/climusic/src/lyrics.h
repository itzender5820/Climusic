#pragma once
/*  MUSICO VERSE 2.0 — lyrics.h
 *  Features:
 *    - Word-level LRC sync (Enhanced LRC <mm:ss.xx> tokens)
 *    - End-of-song scroll fix (active line always centred; blank padding)
 *    - Cancel freeze fix (select() non-blocking pipe read — exits within 100 ms)
 *    - Sidecar .lrc / .txt / .lyrics with graceful fallback
 *    - Async syncedlyrics fetch cached as .lrc
 */
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <regex>
#include <algorithm>
#include <filesystem>
#include <thread>
#include <atomic>
#include <mutex>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// POSIX non-blocking pipe select (Android/Termux compatible)
#include <unistd.h>
#include <sys/select.h>

namespace fs = std::filesystem;

// ─── Data types ──────────────────────────────────────────────────────────────

struct WordToken {
    double      time_sec = 0.0;   // timestamp when this word starts
    std::string text;             // the word text (may include trailing space)
};

struct LrcLine {
    double                  time_sec  = 0.0;
    std::string             full_text;        // full rendered line
    std::vector<WordToken>  words;            // empty = no word-level sync
};

// ─── Lyrics engine ───────────────────────────────────────────────────────────

class Lyrics {
public:
    enum class State { IDLE, FETCHING, FOUND, NOT_FOUND };

    // Load lyrics for the given audio file + metadata.
    // Always call cancel_fetch() before this to kill any running fetch.
    void load(const std::string& audio_path,
              const std::string& title,
              const std::string& artist)
    {
        cancel_fetch();
        {
            std::lock_guard lk(mtx_);
            lines_.clear();
            has_ts_    = false;
            state_     = State::IDLE;
            status_    = "";
        }

        if (try_sidecar(audio_path)) return;

        if (title.empty() && artist.empty()) {
            state_ = State::NOT_FOUND;
            return;
        }

        state_      = State::FETCHING;
        status_     = "Fetching lyrics…";
        cancel_     = false;
        cache_path_ = make_cache_path(audio_path);

        fetch_thread_ = std::thread([this, title, artist] {
            fetch_async(title, artist);
        });
    }

    // Signal the fetch thread to stop and wait for it (at most ~150 ms).
    void cancel_fetch() {
        cancel_ = true;
        if (fetch_thread_.joinable()) fetch_thread_.join();
        cancel_ = false;
    }

    // ── Queries ──────────────────────────────────────────────────────────────

    [[nodiscard]] State       state()      const { return state_.load(); }
    [[nodiscard]] std::string status()     const { std::lock_guard l(mtx_); return status_; }
    [[nodiscard]] bool        has_lyrics() const { std::lock_guard l(mtx_); return !lines_.empty(); }

    // Returns `window` lines centred on the active line.
    // Active line is always at index window/2; edges padded with empty strings.
    // FIX: old code stopped centring near end of song — now always centred.
    [[nodiscard]] std::vector<std::string> visible(double pos, int window) const {
        std::lock_guard l(mtx_);
        if (lines_.empty()) return {};
        int cur  = active_idx(pos);
        int half = window / 2;

        std::vector<std::string> out;
        out.reserve(window);
        for (int i = 0; i < window; ++i) {
            int src = cur - half + i;
            if (src >= 0 && src < (int)lines_.size())
                out.push_back(lines_[src].full_text);
            else
                out.push_back("");   // blank padding — keeps active line centred
        }
        return out;
    }

    // Active line is always at window/2 (fixed centred position).
    [[nodiscard]] int active_in_visible(double /*pos*/, int window) const {
        return window / 2;
    }

    // Returns word tokens for the currently active line (empty if no word sync).
    [[nodiscard]] std::vector<WordToken> active_words(double pos) const {
        std::lock_guard l(mtx_);
        if (lines_.empty()) return {};
        return lines_[active_idx(pos)].words;
    }

    // Index of the currently spoken word within the active line's words array.
    // Returns -1 if no word-level data.
    [[nodiscard]] int active_word_idx(double pos) const {
        std::lock_guard l(mtx_);
        if (lines_.empty()) return -1;
        const auto& words = lines_[active_idx(pos)].words;
        if (words.empty()) return -1;
        int cur = 0;
        for (int i = 0; i < (int)words.size(); ++i)
            if (words[i].time_sec <= pos) cur = i;
        return cur;
    }

private:
    std::vector<LrcLine>  lines_;
    bool                  has_ts_ = false;
    std::atomic<State>    state_{State::IDLE};
    std::string           status_, cache_path_;
    std::thread           fetch_thread_;
    std::atomic<bool>     cancel_{false};
    mutable std::mutex    mtx_;

    // ── Helpers ──────────────────────────────────────────────────────────────

    [[nodiscard]] int active_idx(double pos) const {
        int cur = 0;
        if (has_ts_)
            for (int i = 0; i < (int)lines_.size(); ++i)
                if (lines_[i].time_sec <= pos) cur = i;
        return cur;
    }

    [[nodiscard]] static std::string make_cache_path(const std::string& p) {
        return fs::path(p).replace_extension(".lrc").string();
    }

    bool try_sidecar(const std::string& p) {
        for (const char* ext : {".lrc", ".txt", ".lyrics"}) {
            fs::path c = fs::path(p);
            c.replace_extension(ext);
            if (fs::exists(c) && parse_lrc_file(c.string())) {
                state_  = State::FOUND;
                status_ = "Lyrics loaded";
                return true;
            }
        }
        return false;
    }

    // ── Enhanced LRC parser ──────────────────────────────────────────────────
    // Handles standard LRC  [mm:ss.xx]text
    // and Enhanced LRC      [mm:ss.xx]<mm:ss.xx>word <mm:ss.xx>word ...

    static double parse_ts(const std::ssub_match& m1,
                            const std::ssub_match& m2,
                            const std::ssub_match& m3)
    {
        return std::stod(m1) * 60.0
             + std::stod(m2)
             + std::stod(m3) * 0.01;
    }

    [[nodiscard]] bool parse_lrc_string(const std::string& src) {
        static const std::regex line_ts_re(R"(\[(\d+):(\d+)[\.:](\d+)\])");
        static const std::regex meta_re(R"(\[[a-zA-Z]+:)");
        static const std::regex word_ts_re(R"(<(\d+):(\d+)[\.:](\d+)>)");

        std::vector<LrcLine> tmp;
        bool timed = false;

        std::istringstream ss(src);
        std::string raw;
        while (std::getline(ss, raw)) {
            if (!raw.empty() && raw.back() == '\r') raw.pop_back();
            if (raw.empty() || std::regex_search(raw, meta_re)) continue;

            std::smatch m;
            if (!std::regex_search(raw, m, line_ts_re)) {
                tmp.push_back({0.0, raw, {}});
                continue;
            }

            double line_ts = parse_ts(m[1], m[2], m[3]);
            std::string text = std::regex_replace(raw, line_ts_re, "");

            LrcLine entry;
            entry.time_sec = line_ts;
            timed = true;

            // FIX-1: build full_text by stripping all <word_ts> tokens then
            // collapsing runs of whitespace → single space, trimmed.
            {
                std::string clean = std::regex_replace(text, word_ts_re, "");
                std::string norm;
                norm.reserve(clean.size());
                bool sp = false;
                for (char c : clean) {
                    if (c == ' ' || c == '\t') { if (!sp) norm += ' '; sp = true; }
                    else                        { norm += c; sp = false; }
                }
                size_t s = norm.find_first_not_of(' ');
                size_t e = norm.find_last_not_of(' ');
                entry.full_text = (s == std::string::npos) ? "" : norm.substr(s, e - s + 1);
            }

            if (entry.full_text.empty()) continue;

            // FIX-2: word token extraction via match positions (not sregex_token_iterator).
            // Each <ts> match owns the text between its end and the next match's start.
            {
                auto wit  = std::sregex_iterator(text.begin(), text.end(), word_ts_re);
                auto wend = std::sregex_iterator();
                for (auto it = wit; it != wend; ++it) {
                    const auto& wm = *it;
                    double wts = parse_ts(wm[1], wm[2], wm[3]);

                    size_t wtext_start = (size_t)(wm.position() + wm.length());
                    size_t wtext_end;
                    auto nxt = std::next(it);
                    wtext_end = (nxt != wend) ? (size_t)nxt->position() : text.size();

                    std::string word_text = text.substr(wtext_start, wtext_end - wtext_start);
                    // trim leading + trailing whitespace
                    size_t first = word_text.find_first_not_of(" \t\r\n");
                    if (first == std::string::npos) continue;
                    size_t last = word_text.find_last_not_of(" \t\r\n");
                    word_text = word_text.substr(first, last - first + 1);
                    if (!word_text.empty())
                        entry.words.push_back({wts, word_text});
                }
            }

            tmp.push_back(std::move(entry));
        }

        if (tmp.empty()) return false;

        if (timed)
            std::stable_sort(tmp.begin(), tmp.end(),
                [](const LrcLine& a, const LrcLine& b) {
                    return a.time_sec < b.time_sec;
                });

        std::lock_guard lk(mtx_);
        lines_  = std::move(tmp);
        has_ts_ = timed;
        return true;
    }

    [[nodiscard]] bool parse_lrc_file(const std::string& path) {
        std::ifstream f(path);
        if (!f.is_open()) return false;
        std::string src((std::istreambuf_iterator<char>(f)),
                         std::istreambuf_iterator<char>());
        return parse_lrc_string(src);
    }

    // ── Async fetch via syncedlyrics ─────────────────────────────────────────
    // Uses select() with 100 ms timeout so cancel_ is checked frequently.
    // This prevents the UI from freezing for 30+ seconds when switching songs.

    void fetch_async(const std::string& title, const std::string& artist) {
        // Check syncedlyrics is installed (fast check)
        if (system("python3 -c \"import syncedlyrics\" 2>/dev/null") != 0) {
            std::lock_guard lk(mtx_);
            state_  = State::NOT_FOUND;
            status_ = "Run: pip install syncedlyrics";
            return;
        }
        if (cancel_) return;

        auto esc = [](const std::string& s) {
            std::string o;
            for (char c : s) { if (c == '\'' || c == '\\') o += '\\'; o += c; }
            return o;
        };

        const std::string q   = esc(artist) + " - " + esc(title);
        const std::string cmd =
            "python3 -c \""
            "import syncedlyrics,sys\n"
            "r=syncedlyrics.search('" + q + "',enhanced=True)\n"
            "if not r: r=syncedlyrics.search('" + q + "')\n"
            "sys.stdout.write(r if r else '')\n"
            "\" 2>/dev/null";

        FILE* pipe = popen(cmd.c_str(), "r");
        if (!pipe) {
            std::lock_guard lk(mtx_);
            state_ = State::NOT_FOUND; status_ = "Fetch failed";
            return;
        }

        // ── Non-blocking read with 100 ms select() timeout ───────────────
        // FIX: old code used blocking fgets — caused multi-second UI freezes
        // when cancelling.  Now the thread exits within ~100 ms of cancel_.
        int fd = fileno(pipe);
        std::string result;
        result.reserve(4096);
        char buf[1024];

        while (!cancel_) {
            fd_set rfds;
            FD_ZERO(&rfds);
            FD_SET(fd, &rfds);
            struct timeval tv{0, 100'000};  // 100 ms

            int ret = select(fd + 1, &rfds, nullptr, nullptr, &tv);
            if (ret > 0) {
                if (!fgets(buf, sizeof(buf), pipe)) break;   // EOF
                result += buf;
            } else if (ret < 0) {
                break;   // error
            }
            // ret == 0: timeout → loop again and re-check cancel_
        }
        pclose(pipe);

        if (cancel_) return;

        if (result.size() < 10 || result.find('[') == std::string::npos) {
            std::lock_guard lk(mtx_);
            state_ = State::NOT_FOUND; status_ = "No lyrics found";
            return;
        }

        // Cache to disk
        if (!cache_path_.empty()) {
            std::ofstream cf(cache_path_);
            if (cf.is_open()) cf << result;
        }

        if (parse_lrc_string(result)) {
            std::lock_guard lk(mtx_);
            state_  = State::FOUND;
            status_ = "Lyrics fetched ✓";
        } else {
            std::lock_guard lk(mtx_);
            state_  = State::NOT_FOUND;
            status_ = "No lyrics found";
        }
    }
};
